<?php 
/**
 * Scoreboard.
 */
?>

<div class="cq-score-container">
    <?php _e( 'SCORE', 'campos-quest' ); ?>
    <div class="cq-score">0</div>
</div>
