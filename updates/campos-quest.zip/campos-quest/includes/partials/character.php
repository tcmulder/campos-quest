<?php 
/**
 * Div to house the chosen character that will play in the game.
 */
?>

<div class="cq-character" tabindex="0">
    <div class="cq-character-svg"></div>
    <div class="cq-character-crash" aria-hidden="true"></div>
    <div class="cq-character-backpack">
        <div class="cq-character-score"></div>
    </div>
</div>
