<?php 
/**
 * Container for game animation (including all obstacles, layers, etc. as part of the layer SVG).
 */
?>

<div class="cq-board"></div>
