<?php 
/**
 * Display of version number for the game
 */
?>

<div class="cq-v">v1.3.4</div>
