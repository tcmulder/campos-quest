<?php 
/**
 * Display of version number for the game
 */
?>

<div class="cq-v">v1.4.0</div>
