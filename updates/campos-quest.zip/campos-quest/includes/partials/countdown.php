<?php 
/**
 * Countdown when starting autoplay of a new level.
 */
?>

<div class="cq-countdown"></div>
