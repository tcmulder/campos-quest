import '../svg/level-1.svg';
import '../svg/level-2.svg';
import '../svg/level-3.svg';
import '../svg/level-4.svg';
import '../svg/character-1.svg';
import '../svg/character-2.svg';
import '../svg/character-3.svg';
import '../svg/character-4.svg';
