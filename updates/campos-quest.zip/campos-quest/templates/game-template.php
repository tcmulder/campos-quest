<?php
/**
 * Template Name: Game
 * Description: Full screen game template
 */

require_once CAMPOS_QUEST_PLUGIN_INC . 'index.php';
